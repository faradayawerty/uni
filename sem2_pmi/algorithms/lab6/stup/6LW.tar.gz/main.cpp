#include <iostream>

#include "functions.hpp"

int main()
{
    // std::cout << task3("/home/grigory/Programming/C++/Laboratory/2SST/LABW6/files/t3.txt") << "\n";
    std::cout << task12("/home/grigory/Programming/C++/Laboratory/2SST/LABW6/files/t11.txt") << "\n";
    return 0;
}
